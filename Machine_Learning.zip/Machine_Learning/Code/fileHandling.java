import java.io.*;
public class fileHandling {
	public static void main(String[]args) {
		File output = new File ("bias.txt");
		try {
			FileWriter fw = new FileWriter(output);
			fw.write("Hello World");
			fw.close();
			System.out.println("Written");
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
