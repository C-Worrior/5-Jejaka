import java.io.*;
import java.util.*;
public class process {
	public static void main(String[]args) throws IOException, FileNotFoundException{
		File output = new File("actualY.txt");
		File input = new File("Sample.txt");
		
		FileWriter fw = new FileWriter(output);
		Scanner sc = new Scanner(input);
		
		while(sc.hasNext()) {
			double open = sc.nextDouble();
			double close = sc.nextDouble();
			sc.nextDouble();
			sc.nextDouble();
			sc.nextDouble();
			
			fw.write(close - open +"\n");
		}
	}
}
