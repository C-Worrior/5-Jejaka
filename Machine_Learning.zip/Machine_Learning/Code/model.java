import java.io.*;
import java.util.*;
class Layer{
	public double [][] weight;
	public double [] bias;
	public double [] output;
	public int neu;
	
	public Layer(int i, int n) {
		neu = n;
		weight = new double [n][i];
		bias = new double [n];
		output = new double[n];
	}
	
	public double[] getBias() {
		return bias;
	}
	
	public double[][] getWeight() {
		return weight;
	}
	
	public void setBias(double b []) {
		bias = b;
	}
	
	public void setWeight(double w [][]) {
		weight = w;
	}
	
	public void Forward(double input[]) {
		for(int i = 0; i < neu; i++) {
			double sum =0;
			for(int j = 0; j < 5; j++) {
				sum += input[j] * weight[i][j];
				
			}
			sum += bias[i];
			output[i] = sum;
		}
	}
	
}
class Activation_RL{
	public double [] output;
	public void forward(double [] input) {
		output = new double[input.length];
		for(int i=0; i<input.length; i++) {
			output[i] = input[i] > 0 ? input[i] : 0;
		}
	}
}
class Activation_SM {
	public double [] output;
	double sum;;
	
	public void forward(double [] input) {
		sum =0;
		double [] prob = new double[input.length]; 
		for(int i =0; i<input.length; i++) {
			double exp = Math.exp(input[i]);
			sum+= exp;
		}
		for(int i =0; i<input.length; i++) {
			double exp = Math.exp(input[i]);
			prob [i] = exp/sum;
		}
		output = prob;
	}
}

class model{
	public static void main(String[]args) {
		double [] input = {1.0,2.2,3.3,4.0,5.5};
		Layer layer1 = new Layer(5, 100);
		
		layer1.setWeight(read(5, 100, new File("Weight.txt")));
		layer1.setBias(read(100, new File("Bias.txt")));
		layer1.Forward(input);
		
		Activation_RL activation1 = new Activation_RL();
		activation1.forward(layer1.output);
		
		
		Layer layer2 = new Layer(100, 2);
		layer2.setBias(read(2, new File("Bias2.txt")));
		layer2.setWeight(read(100, 2, new File("Weight2.txt")));
		layer2.Forward(activation1.output);
		
		Activation_SM activation2 = new Activation_SM();
		activation2.forward(layer2.output);
		
		printOut(activation2.output);
		
	}
	
	
	public static double[] read(int neuron, File bias) {
		double [] output = new double [neuron];
		try{Scanner sc = new Scanner(bias);
			for(int i=0; i<output.length; i++ ) {
				output[i] = sc.nextDouble();
			}
			sc.close();
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		return output;
	}
	
	public static double[][] read(int input, int neuron, File weight) {
		double [][] output = new double [neuron][input];
		try{Scanner sc = new Scanner(weight);
			for(int i=0; i<output.length; i++ ) {
				for(int j=0; j<output[i].length;j++) {
					output[i][j] = sc.nextDouble();
				}
			}
			sc.close();
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		return output;
	}
	
	public static void printOut(double [] output) {
		for(int i=0; i<output.length; i++) {
			System.out.println(output[i]);
		}
	}
}

