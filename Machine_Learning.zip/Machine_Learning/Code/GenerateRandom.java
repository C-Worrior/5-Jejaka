import java.io.*;
public class GenerateRandom {
	public static double[][] randWeight(){
		double [][]weight = new double [2][100];
		
		for(int i=0; i<2;i++) {
			for(int j=0; j<100;j++) {
				weight[i][j] = Math.random();
			}
		}
		return weight;
	}
	
	public static double[] randBias(){
		double []bias = new double [2];
		for(int i=0; i<2;i++) {
			bias[i] = Math.random();
		}
		return bias;
	}
	
	public static void printOut(FileWriter fw, double [] output) {
		try {
			for(int i=0; i<output.length; i++) {
				fw.write(String.valueOf(output[i])+"\n");
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void printOut(FileWriter fw, double [][] output) {
		try {
			for(int i=0; i<output.length; i++) {
				for(int j=0; j<output[i].length;j++) {
					fw.write(String.valueOf(output[i][j])+" ");
				}
				fw.write("\n");
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[]args) {
		File bias = new File("Bias2.txt");
		File weight = new File("Weight2.txt");
		
		try {
			FileWriter biasFW = new FileWriter(bias);
			FileWriter weightFW = new FileWriter(weight);
			
			printOut(biasFW, randBias());
			printOut(weightFW, randWeight());
			
			biasFW.close();
			weightFW.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
